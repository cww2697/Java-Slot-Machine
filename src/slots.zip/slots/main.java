package slots;

public class main {
	public static void main(String[] args){
        Slot_Machine slots = new Slot_Machine();
        slots.slots();
    }
}
